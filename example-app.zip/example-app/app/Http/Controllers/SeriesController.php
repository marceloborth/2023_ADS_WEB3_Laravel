<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Serie;

class SeriesController extends Controller
{

    public function create()
    {
        return view('series.create');
    }

    public function index()
    {
        $series = [
            "Lost",
            "Grey's Anatomy",
            "Agents of SHIELDS"
        ];
        
        //Chamando a view e passando uma variável
        //Versão compacta
        return view('series.index', compact('series'));
        
        //Versão original
        //return view('series.index', ['series' => $series]);

        /*
        $html = "<ul>";
        foreach($series as $serie) {
            $html .= "<li>$serie</li>";
        }
        $html .= "</ul>";*/
        //return $html;
    }

    public function store(Request $request) {
        $nome = $request->nome;

        $serie = new Serie();
        $serie->nome = $nome;

        $serie->save();
    }
}
