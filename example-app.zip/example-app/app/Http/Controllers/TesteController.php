<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Teste;

class TesteController extends Controller
{

    public function index()
    {
        //Enviando os registros (objetos) para a view
        $lista = Teste::all();
        return view('teste.index', compact('lista'));

        /*
        Percorre todos os registros
        foreach (Teste::all() as $teste) {
            echo $teste->descricao . "<br>";
        }*/
    }

    public function create()
    {
        return view('teste.create');
    }

    public function store(Request $request)
    {
        //"descricao" é a coluna no BD
        //"nome" é o campo de texto na interface create
        
        //1º forma de inserir
        /*
        $obj = new Teste();
        $obj->descricao = $request->descricao;
        $obj->save();
        */

        //2º forma de inserir
        //$obj = Teste::create(['descricao' => $request->descricao]);
        
        //3º forma de inserir
        $obj = Teste::create($request->all());
        
        //return "Registro {$obj->id} salvo com sucesso: {$obj->descricao}";
        
        return redirect("/teste/index");
    }

    public function destroy(Request $request) {
        $obj = new Teste();
        $obj->id = $request->id;
        $obj->delete();
        return redirect("/teste/index");
    }

}
