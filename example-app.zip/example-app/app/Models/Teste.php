<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Teste extends Model
{
    use HasFactory;

    //Ignora as colunas create_at e updated_at
    public $timestamps = false;

    //Permite preenchimento automático e corrige o erro abaixo:
    //Erro: Add [descricao] to fillable property to allow mass assignment on [App\Models\Teste].
    public $fillable = ['descricao'];
}
